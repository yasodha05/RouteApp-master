import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseRoutingModule } from './course-routing.module';
import { IosComponent } from './ios/ios.component';
import { AndroidComponent } from './android/android.component';


@NgModule({
  imports: [
    CommonModule,
    CourseRoutingModule
  ],
  declarations: [IosComponent, AndroidComponent],
  exports:[IosComponent, AndroidComponent]
})
export class CourseModule { }
