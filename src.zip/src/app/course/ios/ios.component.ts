import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ios',
  templateUrl: './ios.component.html',
  styleUrls: ['./ios.component.css']
})
export class IosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
