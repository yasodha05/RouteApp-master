import { Injectable } from '@angular/core';
import * as firebase from 'firebase';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';

interface User {
  username:string;
  password:string;
}
@Injectable()
export class AuthService {
  user: Observable<User>;
  token:string;
  constructor(private router:Router) { }

  signupUser(username, password) {

    firebase.auth().createUserWithEmailAndPassword(username, password).
    then((res) => {
      console.log(res);
    }).catch((error) => {
      console.log(error);
    });
  }

  signin(username, password) {
   return firebase.auth().signInWithEmailAndPassword(username, password).
    then((res) => {
      console.log(res);
      this.router.navigate(['/']);
      firebase.auth().currentUser.getIdToken().then(
        (token:string) => {
          this.token = token;
        }
      );
    }).catch((error) => {
      console.log(error);
    });
  }

  isAuthenticated():boolean {
    if (this.token != null) {
      return true;
    } else {
      return false;
    }
  }

  onLogout() {
    firebase.auth().signOut();
    this.token = null;
  }
}
