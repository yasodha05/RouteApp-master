import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {Authenticate} from '../authenticate';
import {AuthService} from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form: FormGroup = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });
  @Input() errorMessage: string | null;

  @Output() submitted = new EventEmitter<Authenticate>();
  constructor(private auth:AuthService) { }

  ngOnInit() {
  }
  signin(form:FormGroup) {
    this.auth.signin(this.form.get('email').value, this.form.get('password').value);
  }
}
