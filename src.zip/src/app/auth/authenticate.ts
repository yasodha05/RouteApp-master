export interface Authenticate {
  username: string;
  password: string;
}
