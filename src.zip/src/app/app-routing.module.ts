import {Routes, RouterModule, PreloadAllModules} from '@angular/router';
import {NgModule} from '@angular/core';
import {AndroidComponent} from './course/android/android.component';
import {IosComponent} from './course/ios/ios.component';
import {AuthGuardService} from './auth/auth-guard.service';
import {HomeComponent} from './core/home/home.component';
import {LoginComponent} from './auth/login/login.component';
import {SignupComponent} from './auth/signup/signup.component';


const appRoutes: Routes = [
  {path: '', component: HomeComponent},
  {path:'login', component:LoginComponent},
  {path:'signup', component:SignupComponent},
  {path:'android', canActivate: [AuthGuardService], component:AndroidComponent},
  {path:'ios',  canActivate: [AuthGuardService], component:IosComponent, }
 ];

@NgModule({

  imports: [
    RouterModule.forRoot(appRoutes, {preloadingStrategy: PreloadAllModules})
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {

}
